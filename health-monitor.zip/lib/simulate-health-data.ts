export function simulateHealthData() {
  const now = new Date()
  const timeOfDay = now.getHours()

  // Simulate circadian rhythm effects
  const circadianFactor = Math.sin((timeOfDay / 24) * 2 * Math.PI)

  return {
    heartRate: Math.floor(70 + circadianFactor * 10 + Math.random() * 20),
    oxygenLevels: Math.floor(97 + Math.random() * 3),
    bloodPressure: {
      systolic: Math.floor(120 + circadianFactor * 10 + Math.random() * 20),
      diastolic: Math.floor(80 + circadianFactor * 5 + Math.random() * 10),
    },
    temperature: +(36.5 + circadianFactor * 0.5 + Math.random() * 0.5).toFixed(1),
    timestamp: now.toISOString(),
  }
}

