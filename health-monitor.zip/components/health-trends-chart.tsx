"use client"

import { useState, useEffect, useCallback } from "react"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { LineChart, Line, XAxis, YAxis, ResponsiveContainer } from "recharts"
import { ChartContainer, ChartTooltip, ChartTooltipContent } from "@/components/ui/chart"

interface HealthData {
  heartRate: number
  oxygenLevels: number
  bloodPressure: { systolic: number; diastolic: number }
  temperature: number
}

interface HealthTrendsChartProps {
  data: HealthData
}

export function HealthTrendsChart({ data }: HealthTrendsChartProps) {
  const [chartData, setChartData] = useState<Array<HealthData & { time: string }>>([])

  const addDataPoint = useCallback((newData: HealthData) => {
    setChartData((prevData) => {
      const newPoint = {
        ...newData,
        time: new Date().toLocaleTimeString(),
      }
      const updatedData = [...prevData, newPoint].slice(-60) // Keep last 60 data points (5 minutes)
      return updatedData
    })
  }, [])

  useEffect(() => {
    addDataPoint(data)
    const interval = setInterval(() => {
      addDataPoint({
        heartRate: Math.floor(Math.random() * (100 - 60 + 1) + 60),
        oxygenLevels: Math.floor(Math.random() * (100 - 95 + 1) + 95),
        bloodPressure: {
          systolic: Math.floor(Math.random() * (140 - 90 + 1) + 90),
          diastolic: Math.floor(Math.random() * (90 - 60 + 1) + 60),
        },
        temperature: +(Math.random() * (37.5 - 36.0) + 36.0).toFixed(1),
      })
    }, 1000) // Add a new data point every second

    return () => clearInterval(interval)
  }, [data, addDataPoint])

  return (
    <Card className="col-span-full">
      <CardHeader>
        <CardTitle>Health Trends</CardTitle>
      </CardHeader>
      <CardContent>
        <ChartContainer
          config={{
            heartRate: {
              label: "Heart Rate",
              color: "hsl(var(--chart-1))",
            },
            oxygenLevels: {
              label: "Oxygen Levels",
              color: "hsl(var(--chart-2))",
            },
            systolic: {
              label: "Systolic BP",
              color: "hsl(var(--chart-3))",
            },
            diastolic: {
              label: "Diastolic BP",
              color: "hsl(var(--chart-4))",
            },
            temperature: {
              label: "Temperature",
              color: "hsl(var(--chart-5))",
            },
          }}
          className="h-[400px]"
        >
          <ResponsiveContainer width="100%" height="100%">
            <LineChart data={chartData}>
              <XAxis dataKey="time" />
              <YAxis />
              <ChartTooltip content={<ChartTooltipContent />} />
              <Line type="monotone" dataKey="heartRate" stroke="hsl(var(--chart-1))" strokeWidth={2} dot={false} />
              <Line type="monotone" dataKey="oxygenLevels" stroke="hsl(var(--chart-2))" strokeWidth={2} dot={false} />
              <Line
                type="monotone"
                dataKey="bloodPressure.systolic"
                stroke="hsl(var(--chart-3))"
                strokeWidth={2}
                dot={false}
              />
              <Line
                type="monotone"
                dataKey="bloodPressure.diastolic"
                stroke="hsl(var(--chart-4))"
                strokeWidth={2}
                dot={false}
              />
              <Line type="monotone" dataKey="temperature" stroke="hsl(var(--chart-5))" strokeWidth={2} dot={false} />
            </LineChart>
          </ResponsiveContainer>
        </ChartContainer>
      </CardContent>
    </Card>
  )
}

