"use client"

import { useState } from "react"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Button } from "@/components/ui/button"

export function BMICalculator() {
  const [height, setHeight] = useState("")
  const [weight, setWeight] = useState("")
  const [bmi, setBMI] = useState<number | null>(null)

  const calculateBMI = () => {
    const h = Number.parseFloat(height) / 100 // convert cm to m
    const w = Number.parseFloat(weight)
    if (h > 0 && w > 0) {
      const calculatedBMI = w / (h * h)
      setBMI(Number.parseFloat(calculatedBMI.toFixed(1)))
    }
  }

  return (
    <Card>
      <CardHeader>
        <CardTitle>BMI Calculator</CardTitle>
      </CardHeader>
      <CardContent>
        <div className="space-y-4">
          <Input type="number" placeholder="Height (cm)" value={height} onChange={(e) => setHeight(e.target.value)} />
          <Input type="number" placeholder="Weight (kg)" value={weight} onChange={(e) => setWeight(e.target.value)} />
          <Button onClick={calculateBMI}>Calculate BMI</Button>
          {bmi !== null && <div className="text-2xl font-bold">Your BMI: {bmi}</div>}
        </div>
      </CardContent>
    </Card>
  )
}

