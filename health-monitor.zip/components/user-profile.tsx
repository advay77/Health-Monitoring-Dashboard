"use client"

import { useState } from "react"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Button } from "@/components/ui/button"

export function UserProfile() {
  const [name, setName] = useState("")
  const [age, setAge] = useState("")
  const [gender, setGender] = useState("")

  const saveProfile = () => {
    // In a real application, you would save this data to a backend
    console.log("Saving profile:", { name, age, gender })
  }

  return (
    <Card>
      <CardHeader>
        <CardTitle>User Profile</CardTitle>
      </CardHeader>
      <CardContent>
        <div className="space-y-4">
          <Input placeholder="Name" value={name} onChange={(e) => setName(e.target.value)} />
          <Input type="number" placeholder="Age" value={age} onChange={(e) => setAge(e.target.value)} />
          <Input placeholder="Gender" value={gender} onChange={(e) => setGender(e.target.value)} />
          <Button onClick={saveProfile}>Save Profile</Button>
        </div>
      </CardContent>
    </Card>
  )
}

