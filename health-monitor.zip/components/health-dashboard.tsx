"use client"

import { useState, useEffect } from "react"
import { HeartRateWidget } from "./widgets/heart-rate-widget"
import { OxygenLevelsWidget } from "./widgets/oxygen-levels-widget"
import { BloodPressureWidget } from "./widgets/blood-pressure-widget"
import { TemperatureWidget } from "./widgets/temperature-widget"
import { HealthTrendsChart } from "./health-trends-chart"
import { BMICalculator } from "./bmi-calculator"
import { SleepTracker } from "./sleep-tracker"
import { UserProfile } from "./user-profile"
import { AlertSettings } from "./alert-settings"
import { HistoricalDataView } from "./historical-data-view"
import { simulateHealthData } from "@/lib/simulate-health-data"

export function HealthDashboard() {
  const [healthData, setHealthData] = useState(simulateHealthData())
  const [alertThresholds, setAlertThresholds] = useState({
    heartRate: { min: 60, max: 100 },
    oxygenLevels: { min: 95, max: 100 },
    bloodPressure: {
      systolic: { min: 90, max: 140 },
      diastolic: { min: 60, max: 90 },
    },
    temperature: { min: 36.1, max: 37.2 },
  })

  useEffect(() => {
    const interval = setInterval(() => {
      setHealthData(simulateHealthData())
    }, 5000) // Update every 5 seconds

    return () => clearInterval(interval)
  }, [])

  return (
    <div className="space-y-8">
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
        <HeartRateWidget value={healthData.heartRate} thresholds={alertThresholds.heartRate} />
        <OxygenLevelsWidget value={healthData.oxygenLevels} thresholds={alertThresholds.oxygenLevels} />
        <BloodPressureWidget
          systolic={healthData.bloodPressure.systolic}
          diastolic={healthData.bloodPressure.diastolic}
          thresholds={alertThresholds.bloodPressure}
        />
        <TemperatureWidget value={healthData.temperature} thresholds={alertThresholds.temperature} />
      </div>
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        <BMICalculator />
        <SleepTracker />
      </div>
      <HealthTrendsChart data={healthData} />
      <HistoricalDataView />
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        <UserProfile />
        <AlertSettings thresholds={alertThresholds} setThresholds={setAlertThresholds} />
      </div>
    </div>
  )
}

