import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import type React from "react" // Import React

interface AlertSettingsProps {
  thresholds: {
    heartRate: { min: number; max: number }
    oxygenLevels: { min: number; max: number }
    bloodPressure: {
      systolic: { min: number; max: number }
      diastolic: { min: number; max: number }
    }
    temperature: { min: number; max: number }
  }
  setThresholds: React.Dispatch<React.SetStateAction<AlertSettingsProps["thresholds"]>>
}

export function AlertSettings({ thresholds, setThresholds }: AlertSettingsProps) {
  const handleChange = (metric: string, subMetric: string | null, minMax: "min" | "max", value: string) => {
    setThresholds((prev) => {
      const newThresholds = { ...prev }
      if (subMetric) {
        ;(newThresholds[metric as keyof typeof newThresholds] as any)[subMetric][minMax] = Number.parseFloat(value)
      } else {
        ;(newThresholds[metric as keyof typeof newThresholds] as any)[minMax] = Number.parseFloat(value)
      }
      return newThresholds
    })
  }

  return (
    <Card>
      <CardHeader>
        <CardTitle>Alert Settings</CardTitle>
      </CardHeader>
      <CardContent>
        <div className="space-y-4">
          <div>
            <Label>Heart Rate (BPM)</Label>
            <div className="flex gap-2">
              <Input
                type="number"
                value={thresholds.heartRate.min}
                onChange={(e) => handleChange("heartRate", null, "min", e.target.value)}
                placeholder="Min"
              />
              <Input
                type="number"
                value={thresholds.heartRate.max}
                onChange={(e) => handleChange("heartRate", null, "max", e.target.value)}
                placeholder="Max"
              />
            </div>
          </div>
          <div>
            <Label>Oxygen Levels (%)</Label>
            <div className="flex gap-2">
              <Input
                type="number"
                value={thresholds.oxygenLevels.min}
                onChange={(e) => handleChange("oxygenLevels", null, "min", e.target.value)}
                placeholder="Min"
              />
              <Input
                type="number"
                value={thresholds.oxygenLevels.max}
                onChange={(e) => handleChange("oxygenLevels", null, "max", e.target.value)}
                placeholder="Max"
              />
            </div>
          </div>
          <div>
            <Label>Blood Pressure (mmHg)</Label>
            <div className="flex gap-2">
              <Input
                type="number"
                value={thresholds.bloodPressure.systolic.min}
                onChange={(e) => handleChange("bloodPressure", "systolic", "min", e.target.value)}
                placeholder="Systolic Min"
              />
              <Input
                type="number"
                value={thresholds.bloodPressure.systolic.max}
                onChange={(e) => handleChange("bloodPressure", "systolic", "max", e.target.value)}
                placeholder="Systolic Max"
              />
            </div>
            <div className="flex gap-2 mt-2">
              <Input
                type="number"
                value={thresholds.bloodPressure.diastolic.min}
                onChange={(e) => handleChange("bloodPressure", "diastolic", "min", e.target.value)}
                placeholder="Diastolic Min"
              />
              <Input
                type="number"
                value={thresholds.bloodPressure.diastolic.max}
                onChange={(e) => handleChange("bloodPressure", "diastolic", "max", e.target.value)}
                placeholder="Diastolic Max"
              />
            </div>
          </div>
          <div>
            <Label>Temperature (°C)</Label>
            <div className="flex gap-2">
              <Input
                type="number"
                value={thresholds.temperature.min}
                onChange={(e) => handleChange("temperature", null, "min", e.target.value)}
                placeholder="Min"
              />
              <Input
                type="number"
                value={thresholds.temperature.max}
                onChange={(e) => handleChange("temperature", null, "max", e.target.value)}
                placeholder="Max"
              />
            </div>
          </div>
        </div>
      </CardContent>
    </Card>
  )
}

