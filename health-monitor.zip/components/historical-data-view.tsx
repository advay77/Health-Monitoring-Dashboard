"use client"

import { useState, useEffect } from "react"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { LineChart, Line, XAxis, YAxis, ResponsiveContainer } from "recharts"
import { ChartContainer, ChartTooltip, ChartTooltipContent } from "@/components/ui/chart"
import { simulateHealthData } from "@/lib/simulate-health-data"

export function HistoricalDataView() {
  const [historicalData, setHistoricalData] = useState<any[]>([])
  const [selectedMetric, setSelectedMetric] = useState("heartRate")

  useEffect(() => {
    // Simulate fetching historical data
    const data = Array.from({ length: 24 }, (_, i) => {
      const date = new Date()
      date.setHours(date.getHours() - i)
      return {
        ...simulateHealthData(),
        timestamp: date.toISOString(),
      }
    }).reverse()
    setHistoricalData(data)
  }, [])

  const metrics = {
    heartRate: { label: "Heart Rate", color: "hsl(var(--chart-1))" },
    oxygenLevels: { label: "Oxygen Levels", color: "hsl(var(--chart-2))" },
    "bloodPressure.systolic": { label: "Systolic BP", color: "hsl(var(--chart-3))" },
    "bloodPressure.diastolic": { label: "Diastolic BP", color: "hsl(var(--chart-4))" },
    temperature: { label: "Temperature", color: "hsl(var(--chart-5))" },
  }

  return (
    <Card>
      <CardHeader>
        <CardTitle>Historical Data</CardTitle>
      </CardHeader>
      <CardContent>
        <Select onValueChange={setSelectedMetric} defaultValue={selectedMetric}>
          <SelectTrigger className="w-[180px] mb-4">
            <SelectValue placeholder="Select metric" />
          </SelectTrigger>
          <SelectContent>
            {Object.entries(metrics).map(([key, { label }]) => (
              <SelectItem key={key} value={key}>
                {label}
              </SelectItem>
            ))}
          </SelectContent>
        </Select>
        <ChartContainer
          config={{
            [selectedMetric]: metrics[selectedMetric as keyof typeof metrics],
          }}
          className="h-[300px]"
        >
          <ResponsiveContainer width="100%" height="100%">
            <LineChart data={historicalData}>
              <XAxis dataKey="timestamp" tickFormatter={(timestamp) => new Date(timestamp).toLocaleTimeString()} />
              <YAxis />
              <ChartTooltip content={<ChartTooltipContent />} />
              <Line
                type="monotone"
                dataKey={selectedMetric}
                stroke={metrics[selectedMetric as keyof typeof metrics].color}
                strokeWidth={2}
                dot={false}
              />
            </LineChart>
          </ResponsiveContainer>
        </ChartContainer>
      </CardContent>
    </Card>
  )
}

