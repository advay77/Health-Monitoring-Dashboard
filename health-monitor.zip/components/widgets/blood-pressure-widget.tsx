import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Activity } from "lucide-react"

interface BloodPressureWidgetProps {
  systolic: number
  diastolic: number
}

export function BloodPressureWidget({ systolic, diastolic }: BloodPressureWidgetProps) {
  return (
    <Card className="bg-gradient-to-br from-purple-100 to-purple-50 dark:from-purple-900 dark:to-purple-800">
      <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
        <CardTitle className="text-sm font-medium text-purple-800 dark:text-purple-100">Blood Pressure</CardTitle>
        <Activity className="h-4 w-4 text-purple-600 dark:text-purple-300" />
      </CardHeader>
      <CardContent>
        <div className="text-3xl font-bold text-purple-700 dark:text-purple-200">
          {systolic}/{diastolic} mmHg
        </div>
        <p className="text-xs text-purple-600 dark:text-purple-300">Systolic/Diastolic</p>
      </CardContent>
    </Card>
  )
}

