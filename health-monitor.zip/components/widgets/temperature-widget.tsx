import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Thermometer } from "lucide-react"

interface TemperatureWidgetProps {
  value: number
}

export function TemperatureWidget({ value }: TemperatureWidgetProps) {
  return (
    <Card className="bg-gradient-to-br from-orange-100 to-orange-50 dark:from-orange-900 dark:to-orange-800">
      <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
        <CardTitle className="text-sm font-medium text-orange-800 dark:text-orange-100">Temperature</CardTitle>
        <Thermometer className="h-4 w-4 text-orange-600 dark:text-orange-300" />
      </CardHeader>
      <CardContent>
        <div className="text-3xl font-bold text-orange-700 dark:text-orange-200">{value}°C</div>
        <p className="text-xs text-orange-600 dark:text-orange-300">Body temperature</p>
      </CardContent>
    </Card>
  )
}

