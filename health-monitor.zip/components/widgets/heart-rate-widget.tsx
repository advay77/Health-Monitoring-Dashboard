import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Heart, AlertTriangle } from "lucide-react"

interface HeartRateWidgetProps {
  value: number
  thresholds: { min: number; max: number }
}

export function HeartRateWidget({ value, thresholds }: HeartRateWidgetProps) {
  const isAlert = value < thresholds.min || value > thresholds.max

  return (
    <Card
      className={`bg-gradient-to-br ${isAlert ? "from-red-200 to-red-100 dark:from-red-950 dark:to-red-900" : "from-red-100 to-red-50 dark:from-red-900 dark:to-red-800"}`}
    >
      <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
        <CardTitle className="text-sm font-medium text-red-800 dark:text-red-100">Heart Rate</CardTitle>
        <Heart className="h-4 w-4 text-red-600 dark:text-red-300" />
      </CardHeader>
      <CardContent>
        <div className="flex items-center">
          <div className="text-3xl font-bold text-red-700 dark:text-red-200">{value} BPM</div>
          {isAlert && <AlertTriangle className="ml-2 h-5 w-5 text-red-600 dark:text-red-300" />}
        </div>
        <p className="text-xs text-red-600 dark:text-red-300">Beats per minute</p>
      </CardContent>
    </Card>
  )
}

