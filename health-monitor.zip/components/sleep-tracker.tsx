"use client"

import { useState } from "react"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Button } from "@/components/ui/button"

export function SleepTracker() {
  const [sleepStart, setSleepStart] = useState("")
  const [sleepEnd, setSleepEnd] = useState("")
  const [sleepDuration, setSleepDuration] = useState<string | null>(null)

  const calculateSleepDuration = () => {
    const start = new Date(`2000-01-01T${sleepStart}:00`)
    const end = new Date(`2000-01-01T${sleepEnd}:00`)
    if (end < start) end.setDate(end.getDate() + 1)
    const diff = end.getTime() - start.getTime()
    const hours = Math.floor(diff / 3600000)
    const minutes = Math.floor((diff % 3600000) / 60000)
    setSleepDuration(`${hours} hours ${minutes} minutes`)
  }

  return (
    <Card>
      <CardHeader>
        <CardTitle>Sleep Tracker</CardTitle>
      </CardHeader>
      <CardContent>
        <div className="space-y-4">
          <Input type="time" value={sleepStart} onChange={(e) => setSleepStart(e.target.value)} />
          <Input type="time" value={sleepEnd} onChange={(e) => setSleepEnd(e.target.value)} />
          <Button onClick={calculateSleepDuration}>Calculate Sleep Duration</Button>
          {sleepDuration && <div className="text-2xl font-bold">Sleep Duration: {sleepDuration}</div>}
        </div>
      </CardContent>
    </Card>
  )
}

