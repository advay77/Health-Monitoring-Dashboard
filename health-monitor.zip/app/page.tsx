import { Suspense } from "react"
import { HealthDashboard } from "@/components/health-dashboard"
import { HealthStatsLoading } from "@/components/health-stats-loading"
import { ThemeToggle } from "@/components/theme-toggle"

export default function Home() {
  return (
    <main className="container mx-auto p-4">
      <div className="flex justify-between items-center mb-8">
        <h1 className="text-4xl font-bold">Health Monitoring Dashboard</h1>
        <ThemeToggle />
      </div>
      <Suspense fallback={<HealthStatsLoading />}>
        <HealthDashboard />
      </Suspense>
    </main>
  )
}

